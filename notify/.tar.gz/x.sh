#!/bin/bash

# Define os argumentos
NOME_DO_JOB="Kaolinita"
DESCRICAO="Teste de convergência com ecutwfc variando"

# Chama o script Python com os argumentos
python3 notify_job.py job_run "$NOME_DO_JOB" "$DESCRICAO"
################################################3

# Define os argumentos
NOME_DO_JOB="Kaolinita"
DESCRICAO="Teste de convergência com ecutwfc variando"

# Chama o script Python com os argumentos
python3 notify_job.py job_end "$NOME_DO_JOB" "$DESCRICAO"  "$(pwd)"
